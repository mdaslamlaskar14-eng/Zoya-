package com.zoya.assistant.ui

import com.zoya.assistant.Lang

fun pick(l: Lang, en: String, hi: String, bn: String) = when (l) {
    Lang.EN -> en
    Lang.HI -> hi
    Lang.BN -> bn
}

object S {
    fun tagline(l: Lang) = pick(l, "Your sharp-tongued voice sidekick", "तुम्हारी तेज़-तर्रार वॉइस साथी", "তোমার তেজি ভয়েস সঙ্গী")
    fun idle(l: Lang) = pick(l, "Tap the mic to start", "शुरू करने के लिए माइक दबाओ", "শুরু করতে মাইকে চাপো")
    fun connecting(l: Lang) = pick(l, "Getting my thoughts together…", "एक सेकंड, तैयार हो रही हूँ…", "একটু দাঁড়াও, তৈরি হচ্ছি…")
    fun listening(l: Lang) = pick(l, "I'm listening, go on", "मैं सुन रही हूँ, बोलो", "আমি শুনছি, বলো")
    fun speaking(l: Lang) = pick(l, "Zoya is talking", "ज़ोया बोल रही है", "জোয়া বলছে")
    fun friend(l: Lang) = pick(l, "Friend", "दोस्त", "বন্ধু")
    fun assistant(l: Lang) = pick(l, "Assistant", "असिस्टेंट", "অ্যাসিস্ট্যান্ট")
    fun guide(l: Lang) = pick(l, "What Zoya can control", "ज़ोया क्या-क्या कंट्रोल करती है", "জোয়া কী কী কন্ট্রোল করতে পারে")
    fun guideHint(l: Lang) = pick(
        l,
        "Say these out loud. Calls and texts open the dialer or message screen, you press the final button.",
        "इन्हें बोलकर आज़माओ। कॉल और मैसेज डायलर या मैसेज स्क्रीन खोलते हैं, आख़िरी बटन तुम दबाओगे।",
        "এগুলো বলে দেখো। কল আর মেসেজ ডায়ালার বা মেসেজ স্ক্রিন খোলে, শেষ বোতামটা তুমি চাপবে।",
    )
    fun overlayBtn(l: Lang) = pick(
        l,
        "Allow control while other apps are open",
        "दूसरे ऐप खुले होने पर भी कंट्रोल की अनुमति दो",
        "অন্য অ্যাপ খোলা থাকলেও কন্ট্রোলের অনুমতি দাও",
    )
    fun settings(l: Lang) = pick(l, "Settings", "सेटिंग्स", "সেটিংস")
    fun save(l: Lang) = pick(l, "Save", "सेव", "সেভ")
    fun cancel(l: Lang) = pick(l, "Cancel", "रद्द", "বাতিল")
    fun voice(l: Lang) = pick(l, "Voice", "आवाज़", "ভয়েস")
    fun female(l: Lang) = pick(l, "Female", "महिला", "মেয়ে")
    fun male(l: Lang) = pick(l, "Male", "पुरुष", "ছেলে")
    fun appliesNext(l: Lang) = pick(l, "Changes apply from the next chat.", "बदलाव अगली चैट से लागू होंगे।", "পরিবর্তন পরের চ্যাট থেকে কাজ করবে।")
}
