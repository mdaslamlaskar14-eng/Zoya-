package com.zoya.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Void = Color(0xFF150E17)
val Plum = Color(0xFF241428)
val Magenta = Color(0xFFFF2E7E)
val Gold = Color(0xFFFFC64B)
val Mist = Color(0xFFF3E9F0)

@Composable
fun ZoyaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Magenta,
            onPrimary = Void,
            secondary = Gold,
            background = Void,
            onBackground = Mist,
            surface = Plum,
            onSurface = Mist,
            surfaceVariant = Plum,
            onSurfaceVariant = Mist.copy(alpha = 0.7f),
        ),
        content = content,
    )
}
