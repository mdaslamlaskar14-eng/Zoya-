package com.zoya.assistant.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Asks xAI's Grok a question and returns a short spoken-style answer. */
class GrokClient(base: OkHttpClient, private val apiKey: String) {
    private val http = base.newBuilder().readTimeout(40, TimeUnit.SECONDS).build()

    suspend fun ask(question: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            "No Grok API key set. Ask the user to add it in Settings."
        } else {
            val body = JSONObject()
                .put("model", MODEL)
                .put("stream", false)
                .put(
                    "messages",
                    JSONArray()
                        .put(
                            JSONObject().put("role", "system").put(
                                "content",
                                "Answer in under 100 words, plain spoken language, no markdown, no lists.",
                            ),
                        )
                        .put(JSONObject().put("role", "user").put("content", question)),
                )
            val req = Request.Builder()
                .url("https://api.x.ai/v1/chat/completions")
                .header("Authorization", "Bearer $apiKey")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { r ->
                val text = r.body?.string().orEmpty()
                if (!r.isSuccessful) {
                    "Grok request failed with HTTP ${r.code}"
                } else {
                    JSONObject(text).getJSONArray("choices").getJSONObject(0)
                        .getJSONObject("message").getString("content")
                }
            }
        }
    }

    companion object {
        // Change this if xAI renames or retires the model.
        const val MODEL = "grok-4"
    }
}
