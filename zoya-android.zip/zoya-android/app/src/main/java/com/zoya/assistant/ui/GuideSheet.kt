package com.zoya.assistant.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.FlashlightOn
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Sms
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zoya.assistant.Lang

private data class GuideItem(val icon: ImageVector, val title: String, val example: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuideSheet(lang: Lang, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val items = listOf(
        GuideItem(
            Icons.Outlined.Apps,
            pick(lang, "Open apps", "ऐप खोलना", "অ্যাপ খোলা"),
            pick(lang, "\"Open WhatsApp\"", "\"व्हाट्सऐप खोलो\"", "\"হোয়াটসঅ্যাপ খোলো\""),
        ),
        GuideItem(
            Icons.Outlined.Public,
            pick(lang, "Websites", "वेबसाइट", "ওয়েবসাইট"),
            pick(lang, "\"Open youtube.com\"", "\"youtube.com खोलो\"", "\"youtube.com খোলো\""),
        ),
        GuideItem(
            Icons.Outlined.Search,
            pick(lang, "Web search", "वेब सर्च", "ওয়েব সার্চ"),
            pick(lang, "\"Search best phones under 20000\"", "\"20000 के अंदर बेस्ट फोन सर्च करो\"", "\"২০০০০ টাকার মধ্যে সেরা ফোন সার্চ করো\""),
        ),
        GuideItem(
            Icons.Outlined.Call,
            pick(lang, "Calls", "कॉल", "কল"),
            pick(lang, "\"Call 9876543210\"", "\"9876543210 पर कॉल करो\"", "\"9876543210 নম্বরে কল করো\""),
        ),
        GuideItem(
            Icons.Outlined.Sms,
            pick(lang, "Text messages", "टेक्स्ट मैसेज", "টেক্সট মেসেজ"),
            pick(lang, "\"Text 9876543210 I'm running late\"", "\"9876543210 को मैसेज करो, मुझे देर होगी\"", "\"9876543210 কে মেসেজ করো, আমার দেরি হবে\""),
        ),
        GuideItem(
            Icons.Outlined.Alarm,
            pick(lang, "Alarms", "अलार्म", "অ্যালার্ম"),
            pick(lang, "\"Set an alarm for 6:30 AM\"", "\"सुबह 6:30 का अलार्म लगाओ\"", "\"সকাল ৬:৩০ এ অ্যালার্ম দাও\""),
        ),
        GuideItem(
            Icons.Outlined.FlashlightOn,
            pick(lang, "Flashlight", "टॉर्च", "টর্চ"),
            pick(lang, "\"Turn on the flashlight\"", "\"टॉर्च चालू करो\"", "\"টর্চ জ্বালাও\""),
        ),
        GuideItem(
            Icons.Outlined.AutoAwesome,
            pick(lang, "Ask Grok", "Grok से पूछो", "Grok কে জিজ্ঞেস করো"),
            pick(lang, "\"Ask Grok what's new in tech\"", "\"Grok से पूछो टेक में क्या नया है\"", "\"Grok কে জিজ্ঞেস করো টেকে নতুন কী\""),
        ),
    )

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(S.guide(lang), style = MaterialTheme.typography.titleLarge)
            Text(S.guideHint(lang), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            items.forEach { item ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Icon(item.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column {
                        Text(item.title, style = MaterialTheme.typography.titleSmall)
                        Text(item.example, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            OutlinedButton(
                onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(S.overlayBtn(lang)) }
        }
    }
}
