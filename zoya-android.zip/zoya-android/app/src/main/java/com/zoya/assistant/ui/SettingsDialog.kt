package com.zoya.assistant.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.zoya.assistant.Settings
import com.zoya.assistant.VoiceGender

@Composable
fun SettingsDialog(s: Settings, onDismiss: () -> Unit, onSave: (Settings) -> Unit) {
    var gemini by remember { mutableStateOf(s.geminiKey) }
    var grok by remember { mutableStateOf(s.grokKey) }
    var voice by remember { mutableStateOf(s.voice) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(S.settings(s.lang)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = gemini,
                    onValueChange = { gemini = it },
                    label = { Text("Gemini API key") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                )
                OutlinedTextField(
                    value = grok,
                    onValueChange = { grok = it },
                    label = { Text("Grok (xAI) API key") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                )
                Text(S.voice(s.lang), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = voice == VoiceGender.FEMALE,
                        onClick = { voice = VoiceGender.FEMALE },
                        label = { Text(S.female(s.lang)) },
                    )
                    FilterChip(
                        selected = voice == VoiceGender.MALE,
                        onClick = { voice = VoiceGender.MALE },
                        label = { Text(S.male(s.lang)) },
                    )
                }
                Text(
                    S.appliesNext(s.lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(s.copy(geminiKey = gemini.trim(), grokKey = grok.trim(), voice = voice)) }) {
                Text(S.save(s.lang))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(S.cancel(s.lang)) } },
    )
}
