package com.zoya.assistant.service

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.zoya.assistant.MainActivity
import com.zoya.assistant.Status
import com.zoya.assistant.ZoyaApplication

/** Quick Settings tile: tap to open Zoya and start talking, tap again to stop. */
class ZoyaTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        val engine = (application as ZoyaApplication).engine
        if (engine.state.value.status != Status.IDLE) {
            ZoyaService.stop(this)
            qsTile?.apply { state = Tile.STATE_INACTIVE; updateTile() }
            return
        }
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(MainActivity.EXTRA_AUTOSTART, true)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(
                this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }

    private fun refresh() {
        val engine = (application as ZoyaApplication).engine
        qsTile?.apply {
            state = if (engine.state.value.status != Status.IDLE) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "Zoya"
            updateTile()
        }
    }
}
