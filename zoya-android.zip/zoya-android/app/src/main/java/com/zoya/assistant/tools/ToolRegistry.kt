package com.zoya.assistant.tools

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import org.json.JSONArray
import org.json.JSONObject

/** The 8 phone-control tools Zoya can call during a live conversation. */
class ToolRegistry(private val ctx: Context, private val grok: GrokClient) {

    val declarations: JSONArray = JSONArray()
        .put(fn("open_app", "Opens an installed app on the phone by its name.", mapOf("app_name" to "App name as shown on the phone, in English letters, e.g. WhatsApp"), listOf("app_name")))
        .put(fn("open_website", "Opens a website in the browser.", mapOf("url" to "Website address, e.g. youtube.com"), listOf("url")))
        .put(fn("search_web", "Searches Google for a query in the browser.", mapOf("query" to "What to search for"), listOf("query")))
        .put(fn("make_call", "Opens the phone dialer with a number filled in. The user presses call.", mapOf("number" to "Phone number digits"), listOf("number")))
        .put(fn("send_sms", "Opens the SMS app with the number and message filled in. The user presses send.", mapOf("number" to "Phone number digits", "message" to "Message text"), listOf("number", "message")))
        .put(fn("set_alarm", "Sets an alarm at a given time (24-hour clock).", mapOf("hour" to "Hour 0-23", "minute" to "Minute 0-59", "label" to "Optional label"), listOf("hour", "minute")))
        .put(fn("toggle_flashlight", "Turns the phone flashlight on or off.", mapOf("on" to "true to turn on, false to turn off"), listOf("on")))
        .put(fn("ask_grok", "Asks Grok (xAI) a question, good for live news and current events.", mapOf("question" to "The question to ask"), listOf("question")))

    private fun fn(name: String, desc: String, props: Map<String, String>, required: List<String>): JSONObject {
        val p = JSONObject()
        props.forEach { (k, v) -> p.put(k, JSONObject().put("type", "STRING").put("description", v)) }
        return JSONObject()
            .put("name", name)
            .put("description", desc)
            .put("parameters", JSONObject().put("type", "OBJECT").put("properties", p).put("required", JSONArray(required)))
    }

    suspend fun execute(name: String, a: JSONObject): JSONObject = try {
        when (name) {
            "open_app" -> openApp(a.optString("app_name"))
            "open_website" -> {
                var url = a.optString("url").trim()
                if (!url.startsWith("http")) url = "https://$url"
                launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                ok("opened $url")
            }
            "search_web" -> {
                val q = a.optString("query")
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
                ok("searched for $q")
            }
            "make_call" -> {
                launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(a.optString("number")))))
                ok("dialer opened, user must press call")
            }
            "send_sms" -> {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(a.optString("number"))))
                i.putExtra("sms_body", a.optString("message"))
                launch(i)
                ok("message screen opened, user must press send")
            }
            "set_alarm" -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Zoya alarm"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                launch(i)
                ok("alarm set for ${a.optInt("hour")}:${"%02d".format(a.optInt("minute"))}")
            }
            "toggle_flashlight" -> {
                val on = a.optString("on").equals("true", ignoreCase = true) || a.optBoolean("on", false)
                val cm = ctx.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.firstOrNull {
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                if (id == null) err("no flashlight on this phone") else {
                    cm.setTorchMode(id, on)
                    ok(if (on) "flashlight on" else "flashlight off")
                }
            }
            "ask_grok" -> JSONObject().put("status", "ok").put("answer", grok.ask(a.optString("question")))
            else -> err("unknown tool $name")
        }
    } catch (e: Exception) {
        err(e.message ?: "tool failed")
    }

    private fun openApp(query: String): JSONObject {
        val pm = ctx.packageManager
        val q = query.trim().lowercase()
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0,
        )
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return err("no installed app matches '$query'")
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return err("cannot launch '$query'")
        launch(intent)
        return ok("opened ${match.loadLabel(pm)}")
    }

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun ok(msg: String) = JSONObject().put("status", "ok").put("detail", msg)
    private fun err(msg: String) = JSONObject().put("status", "error").put("message", msg)
}
