package com.zoya.assistant

import android.app.Application

class ZoyaApplication : Application() {
    lateinit var engine: ZoyaEngine
        private set

    override fun onCreate() {
        super.onCreate()
        engine = ZoyaEngine(this)
    }
}
