package com.zoya.assistant.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.zoya.assistant.MainActivity
import com.zoya.assistant.R
import com.zoya.assistant.ZoyaApplication

/** Foreground service so the mic session keeps running while the app is in the background. */
class ZoyaService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val engine = (application as ZoyaApplication).engine
        if (intent?.action == ACTION_STOP) {
            engine.stop()
            stopSelf()
            return START_NOT_STICKY
        }

        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        engine.onEnded = { stopSelf() }
        engine.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        val engine = (application as ZoyaApplication).engine
        engine.onEnded = null
        engine.stop()
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Zoya session", NotificationManager.IMPORTANCE_LOW),
        )
    }

    private fun buildNotification() = run {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ZoyaService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE,
        )
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Zoya is listening")
            .setContentText("Tap to open, or stop the session.")
            .setContentIntent(open)
            .addAction(R.drawable.ic_tile, "Stop", stop)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_START = "com.zoya.assistant.START"
        const val ACTION_STOP = "com.zoya.assistant.STOP"
        private const val CHANNEL = "zoya_session"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, ZoyaService::class.java).setAction(ACTION_START),
            )
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, ZoyaService::class.java).setAction(ACTION_STOP))
        }
    }
}
