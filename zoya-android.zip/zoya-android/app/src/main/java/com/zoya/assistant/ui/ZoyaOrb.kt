package com.zoya.assistant.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.zoya.assistant.Status
import kotlin.math.cos
import kotlin.math.sin

/** A pseudo-3D orb: shaded sphere with three tumbling rings. Pulses with the audio level. */
@Composable
fun ZoyaOrb(status: Status, level: Float, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "orb")
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing)),
        label = "spin",
    )
    val breathe by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe",
    )
    val lvl by animateFloatAsState(level.coerceIn(0f, 1f), tween(80), label = "lvl")
    val core = lerp(Magenta, Gold, if (status == Status.SPEAKING) 0.45f else 0f)
    val idleScale = if (status == Status.IDLE) 0.9f else 1f

    Canvas(modifier) {
        val c = center
        val r = size.minDimension * 0.19f * idleScale * (1f + 0.05f * breathe + 0.22f * lvl)

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(core.copy(alpha = 0.30f + 0.35f * lvl), Color.Transparent),
                center = c,
                radius = r * 2.6f,
            ),
            radius = r * 2.6f,
            center = c,
        )

        // Ring params: tilt, base rotation, rotation speed multiplier, radius scale
        val rings = listOf(
            floatArrayOf(62f, 0f, 1f, 1.55f),
            floatArrayOf(62f, 60f, -1f, 1.8f),
            floatArrayOf(62f, 120f, 2f, 2.05f),
        )

        fun point(radius: Float, t: Double, tiltDeg: Float, rotDeg: Float): Triple<Float, Float, Float> {
            val x0 = (cos(t) * radius).toFloat()
            val y0 = (sin(t) * radius).toFloat()
            val tilt = Math.toRadians(tiltDeg.toDouble())
            val y1 = (y0 * cos(tilt)).toFloat()
            val z = (y0 * sin(tilt)).toFloat()
            val rot = Math.toRadians(rotDeg.toDouble())
            val x = (x0 * cos(rot) - y1 * sin(rot)).toFloat()
            val y = (x0 * sin(rot) + y1 * cos(rot)).toFloat()
            return Triple(x, y, z)
        }

        fun drawRings(front: Boolean) {
            rings.forEachIndexed { i, ring ->
                val radius = r * ring[3]
                val rot = ring[1] + spin * ring[2]
                val segments = 72
                for (s in 0 until segments) {
                    val a = point(radius, s * 2 * Math.PI / segments, ring[0], rot)
                    val b = point(radius, (s + 1) * 2 * Math.PI / segments, ring[0], rot)
                    val zMid = (a.third + b.third) / 2f
                    if ((zMid >= 0f) == front) {
                        drawLine(
                            color = core.copy(alpha = if (front) 0.85f else 0.3f),
                            start = Offset(c.x + a.first, c.y + a.second),
                            end = Offset(c.x + b.first, c.y + b.second),
                            strokeWidth = (if (front) 2.2f else 1.4f) * density,
                        )
                    }
                }
                val dotT = Math.toRadians((spin * (i + 1)).toDouble())
                val d = point(radius, dotT, ring[0], rot)
                if ((d.third >= 0f) == front) {
                    drawCircle(
                        color = Color.White,
                        radius = (if (front) 4.5f else 3f) * density,
                        center = Offset(c.x + d.first, c.y + d.second),
                    )
                }
            }
        }

        drawRings(front = false)

        val light = lerp(core, Color.White, 0.55f)
        val dark = lerp(core, Color.Black, 0.55f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(light, core, dark),
                center = Offset(c.x - r * 0.35f, c.y - r * 0.4f),
                radius = r * 1.6f,
            ),
            radius = r,
            center = c,
        )
        drawCircle(Color.White.copy(alpha = 0.25f), r * 0.12f, Offset(c.x - r * 0.38f, c.y - r * 0.42f))

        drawRings(front = true)
    }
}
