package com.zoya.assistant

import android.app.Application
import android.media.AudioManager
import com.zoya.assistant.audio.AudioEngine
import com.zoya.assistant.live.GeminiLiveClient
import com.zoya.assistant.tools.GrokClient
import com.zoya.assistant.tools.ToolRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class Status { IDLE, CONNECTING, LISTENING, SPEAKING }

data class UiState(
    val status: Status = Status.IDLE,
    val level: Float = 0f,
    val log: List<String> = emptyList(),
    val error: String? = null,
)

/** Owns one live voice session: mic -> Gemini Live -> speaker, plus tool calls. */
class ZoyaEngine(private val app: Application) {

    val settingsStore = SettingsStore(app)

    private val http = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val live = GeminiLiveClient(http)
    private val audioManager = app.getSystemService(AudioManager::class.java)

    private var audio: AudioEngine? = null
    private var tools: ToolRegistry? = null
    @Volatile private var running = false
    @Volatile private var ready = false

    /** Set by ZoyaService so it can shut itself down when the session ends. */
    var onEnded: (() -> Unit)? = null

    fun start() {
        if (running) return
        val s = settingsStore.load()
        if (s.geminiKey.isBlank()) {
            _state.value = UiState(error = "Add your Gemini API key in Settings first.")
            onEnded?.invoke()
            return
        }
        running = true
        ready = false
        _state.value = UiState(status = Status.CONNECTING)

        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = true

        val registry = ToolRegistry(app, GrokClient(http, s.grokKey))
        tools = registry

        audio = AudioEngine(
            onMic = { buf, n -> if (ready) live.sendAudio(buf, n) },
            onMicLevel = { l -> if (_state.value.status == Status.LISTENING) setLevel(l) },
            onOutLevel = { l -> if (_state.value.status == Status.SPEAKING) setLevel(l) },
            onPlaybackIdle = { setStatus(Status.LISTENING) },
        )

        live.connect(
            apiKey = s.geminiKey,
            model = MODEL,
            systemInstruction = Persona.build(s),
            voiceName = s.voice.voiceName,
            toolDeclarations = registry.declarations,
            listener = object : GeminiLiveClient.Listener {
                override fun onReady() {
                    ready = true
                    setStatus(Status.LISTENING)
                    log("Connected. Say hi.")
                    audio?.startCapture()
                }

                override fun onAudio(pcm: ByteArray) {
                    setStatus(Status.SPEAKING)
                    audio?.play(pcm)
                }

                override fun onInterrupted() {
                    audio?.interrupt()
                    setStatus(Status.LISTENING)
                }

                override fun onTurnComplete() {
                    audio?.markTurnComplete()
                }

                override fun onToolCall(id: String, name: String, args: JSONObject) {
                    scope.launch {
                        log("Tool: $name")
                        val result = registry.execute(name, args)
                        live.sendToolResponse(id, name, result)
                    }
                }

                override fun onClosed(reason: String) {
                    if (running) {
                        log("Session closed: $reason")
                        stop()
                    }
                }

                override fun onError(message: String) {
                    _state.update { it.copy(error = message) }
                    stop()
                }
            },
        )
    }

    fun stop() {
        val wasRunning = running
        running = false
        ready = false
        audio?.release()
        audio = null
        live.close()
        runCatching {
            audioManager.isSpeakerphoneOn = false
            audioManager.mode = AudioManager.MODE_NORMAL
        }
        _state.update { it.copy(status = Status.IDLE, level = 0f) }
        if (wasRunning) onEnded?.invoke()
    }

    private fun setStatus(s: Status) =
        _state.update { if (!running) it else it.copy(status = s, level = 0f) }

    private fun setLevel(l: Float) = _state.update { it.copy(level = l) }

    private fun log(line: String) =
        _state.update { it.copy(log = (it.log + line).takeLast(3)) }

    companion object {
        // Model id from Google's Live API docs. Update if Google renames it.
        const val MODEL = "gemini-3.1-flash-live-preview"
    }
}
