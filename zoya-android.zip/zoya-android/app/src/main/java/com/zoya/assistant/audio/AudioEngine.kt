package com.zoya.assistant.audio

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.sqrt

/** Captures 16 kHz mic audio and plays back 24 kHz model audio with instant barge-in. */
class AudioEngine(
    private val onMic: (ByteArray, Int) -> Unit,
    private val onMicLevel: (Float) -> Unit,
    private val onOutLevel: (Float) -> Unit,
    private val onPlaybackIdle: () -> Unit,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var record: AudioRecord? = null
    private var captureJob: Job? = null

    private val queue = Channel<ByteArray>(Channel.UNLIMITED)
    private val pending = AtomicInteger(0)
    @Volatile private var turnDone = false

    private val track: AudioTrack

    init {
        val minBuf = AudioTrack.getMinBufferSize(
            OUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
        )
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(OUT_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
            )
            .setBufferSizeInBytes(maxOf(minBuf, OUT_RATE))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track.play()

        scope.launch {
            for (chunk in queue) {
                onOutLevel(level(chunk, chunk.size))
                track.write(chunk, 0, chunk.size)
                if (pending.decrementAndGet() <= 0 && turnDone) {
                    turnDone = false
                    onPlaybackIdle()
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun startCapture() {
        val minBuf = AudioRecord.getMinBufferSize(
            IN_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            IN_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, CHUNK_BYTES * 4),
        )
        if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(rec.audioSessionId)?.enabled = true
        if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId)?.enabled = true
        record = rec
        rec.startRecording()

        captureJob = scope.launch {
            val buf = ByteArray(CHUNK_BYTES) // 40 ms
            while (isActive) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) {
                    onMicLevel(level(buf, n))
                    onMic(buf, n)
                } else if (n < 0) break
            }
        }
    }

    fun play(pcm: ByteArray) {
        pending.incrementAndGet()
        queue.trySend(pcm)
    }

    /** User barged in: drop everything queued and silence the speaker right now. */
    fun interrupt() {
        while (true) {
            val r = queue.tryReceive()
            if (r.isSuccess) pending.decrementAndGet() else break
        }
        turnDone = false
        runCatching {
            track.pause()
            track.flush()
            track.play()
        }
    }

    fun markTurnComplete() {
        turnDone = true
        if (pending.get() <= 0) {
            turnDone = false
            onPlaybackIdle()
        }
    }

    fun release() {
        captureJob?.cancel()
        runCatching { record?.stop() }
        runCatching { record?.release() }
        record = null
        queue.close()
        scope.cancel()
        runCatching { track.stop() }
        runCatching { track.release() }
    }

    private fun level(buf: ByteArray, n: Int): Float {
        var sum = 0.0
        var count = 0
        var i = 0
        while (i + 1 < n) {
            val s = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
            val v = s.toShort().toInt()
            sum += v.toDouble() * v
            count++
            i += 2
        }
        if (count == 0) return 0f
        return (sqrt(sum / count) / 32768.0 * 4.0).toFloat().coerceIn(0f, 1f)
    }

    companion object {
        const val IN_RATE = 16000
        const val OUT_RATE = 24000
        private const val CHUNK_BYTES = 1280 // 640 samples = 40 ms at 16 kHz
    }
}
