package com.zoya.assistant

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.zoya.assistant.ui.ZoyaRoot
import com.zoya.assistant.ui.ZoyaTheme

class MainActivity : ComponentActivity() {

    private var autoStart by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        autoStart = intent?.getBooleanExtra(EXTRA_AUTOSTART, false) == true
        val engine = (application as ZoyaApplication).engine
        setContent {
            ZoyaTheme {
                ZoyaRoot(engine, autoStart) { autoStart = false }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_AUTOSTART, false)) autoStart = true
    }

    companion object {
        const val EXTRA_AUTOSTART = "autostart"
    }
}
