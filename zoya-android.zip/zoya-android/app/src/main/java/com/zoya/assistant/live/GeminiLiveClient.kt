package com.zoya.assistant.live

import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject

/**
 * Minimal Gemini Live API client over a raw WebSocket (BidiGenerateContent).
 * Audio in: 16 kHz PCM16 mono. Audio out: 24 kHz PCM16 mono.
 */
class GeminiLiveClient(private val http: OkHttpClient) {

    interface Listener {
        fun onReady()
        fun onAudio(pcm: ByteArray)
        fun onInterrupted()
        fun onTurnComplete()
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onClosed(reason: String)
        fun onError(message: String)
    }

    private var ws: WebSocket? = null

    fun connect(
        apiKey: String,
        model: String,
        systemInstruction: String,
        voiceName: String,
        toolDeclarations: JSONArray,
        listener: Listener,
    ) {
        val url = "wss://generativelanguage.googleapis.com/ws/" +
            "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"

        val setup = JSONObject().put(
            "setup",
            JSONObject()
                .put("model", "models/$model")
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO"))
                        .put(
                            "speechConfig",
                            JSONObject().put(
                                "voiceConfig",
                                JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName)),
                            ),
                        ),
                )
                .put(
                    "systemInstruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction))),
                )
                .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", toolDeclarations))),
        )

        ws = http.newWebSocket(
            Request.Builder().url(url).build(),
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    webSocket.send(setup.toString())
                }

                override fun onMessage(webSocket: WebSocket, text: String) = handle(text, listener)

                override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8(), listener)

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(1000, null)
                    listener.onClosed(reason.ifBlank { "closed ($code)" })
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    val code = response?.code?.let { " (HTTP $it)" } ?: ""
                    listener.onError((t.message ?: "Connection failed") + code)
                }
            },
        )
    }

    private fun handle(text: String, listener: Listener) {
        val msg = runCatching { JSONObject(text) }.getOrNull() ?: return

        if (msg.has("setupComplete")) listener.onReady()

        msg.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) listener.onInterrupted()

            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                    if (inline.optString("mimeType").startsWith("audio/")) {
                        listener.onAudio(Base64.decode(inline.optString("data"), Base64.DEFAULT))
                    }
                }
            }
            if (sc.optBoolean("turnComplete")) listener.onTurnComplete()
        }

        msg.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                listener.onToolCall(
                    c.optString("id"),
                    c.optString("name"),
                    c.optJSONObject("args") ?: JSONObject(),
                )
            }
        }
    }

    fun sendAudio(pcm: ByteArray, length: Int) {
        val payload = JSONObject().put(
            "realtimeInput",
            JSONObject().put(
                "audio",
                JSONObject()
                    .put("data", Base64.encodeToString(pcm, 0, length, Base64.NO_WRAP))
                    .put("mimeType", "audio/pcm;rate=16000"),
            ),
        )
        ws?.send(payload.toString())
    }

    fun sendToolResponse(id: String, name: String, result: JSONObject) {
        val payload = JSONObject().put(
            "toolResponse",
            JSONObject().put(
                "functionResponses",
                JSONArray().put(
                    JSONObject().put("id", id).put("name", name).put("response", JSONObject().put("result", result)),
                ),
            ),
        )
        ws?.send(payload.toString())
    }

    fun close() {
        ws?.close(1000, "bye")
        ws = null
    }
}
