package com.zoya.assistant.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zoya.assistant.Lang
import com.zoya.assistant.Mode
import com.zoya.assistant.Status
import com.zoya.assistant.ZoyaEngine
import com.zoya.assistant.service.ZoyaService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZoyaRoot(engine: ZoyaEngine, autoStart: Boolean, onAutoStartHandled: () -> Unit) {
    val ctx = LocalContext.current
    val ui by engine.state.collectAsStateWithLifecycle()
    var settings by remember { mutableStateOf(engine.settingsStore.load()) }
    var showSettings by remember { mutableStateOf(false) }
    var showGuide by remember { mutableStateOf(false) }
    val lang = settings.lang
    val active = ui.status != Status.IDLE

    val permissions = remember {
        buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.RECORD_AUDIO] == true) ZoyaService.start(ctx)
    }
    fun begin() {
        val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micOk) ZoyaService.start(ctx) else launcher.launch(permissions)
    }

    LaunchedEffect(autoStart) {
        if (autoStart) {
            onAutoStartHandled()
            if (!active) begin()
        }
    }

    fun update(s: com.zoya.assistant.Settings) {
        settings = s
        engine.settingsStore.save(s)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Void)
            .windowInsetsPadding(WindowInsets.systemBars)
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Zoya", fontSize = 32.sp, fontWeight = FontWeight.SemiBold, color = Mist)
                Text(S.tagline(lang), style = MaterialTheme.typography.bodySmall, color = Mist.copy(alpha = 0.6f))
            }
            IconButton(onClick = { showGuide = true }) {
                Icon(Icons.Outlined.Apps, contentDescription = S.guide(lang), tint = Mist)
            }
            IconButton(onClick = { showSettings = true }) {
                Icon(Icons.Outlined.Settings, contentDescription = S.settings(lang), tint = Mist)
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Lang.entries.forEach { l ->
                FilterChip(
                    selected = settings.lang == l,
                    onClick = { update(settings.copy(lang = l)) },
                    label = { Text(l.label) },
                )
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            ZoyaOrb(ui.status, ui.level, Modifier.size(320.dp))
        }

        Text(
            when (ui.status) {
                Status.IDLE -> S.idle(lang)
                Status.CONNECTING -> S.connecting(lang)
                Status.LISTENING -> S.listening(lang)
                Status.SPEAKING -> S.speaking(lang)
            },
            color = Mist.copy(alpha = 0.8f),
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
        )
        ui.error?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = Gold, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(6.dp))
        ui.log.forEach {
            Text(it, color = Mist.copy(alpha = 0.4f), style = MaterialTheme.typography.labelSmall)
        }

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = settings.mode == Mode.FRIEND,
                onClick = { update(settings.copy(mode = Mode.FRIEND)) },
                label = { Text(S.friend(lang)) },
            )
            FilterChip(
                selected = settings.mode == Mode.ASSISTANT,
                onClick = { update(settings.copy(mode = Mode.ASSISTANT)) },
                label = { Text(S.assistant(lang)) },
            )
        }

        Spacer(Modifier.height(20.dp))
        Box(
            Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(if (active) Plum else Magenta)
                .clickable { if (active) ZoyaService.stop(ctx) else begin() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (active) Icons.Filled.Stop else Icons.Filled.Mic,
                contentDescription = null,
                tint = if (active) Mist else Void,
                modifier = Modifier.size(34.dp),
            )
        }
        Spacer(Modifier.height(20.dp))
    }

    if (showSettings) {
        SettingsDialog(
            s = settings,
            onDismiss = { showSettings = false },
            onSave = { update(it); showSettings = false },
        )
    }
    if (showGuide) GuideSheet(lang = lang, onDismiss = { showGuide = false })
}
