package com.zoya.assistant

import android.content.Context

enum class Lang(val label: String, val promptName: String) {
    BN("বাংলা", "Bangla (Bengali)"),
    HI("हिन्दी", "Hindi"),
    EN("English", "English"),
}

enum class Mode { FRIEND, ASSISTANT }

// Gemini Live prebuilt voices. Swap names if Google changes the list.
enum class VoiceGender(val voiceName: String) {
    FEMALE("Aoede"),
    MALE("Orus"),
}

data class Settings(
    val geminiKey: String,
    val grokKey: String,
    val lang: Lang,
    val mode: Mode,
    val voice: VoiceGender,
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("zoya", Context.MODE_PRIVATE)

    fun load(): Settings = Settings(
        geminiKey = prefs.getString("gemini", null) ?: BuildConfig.GEMINI_API_KEY,
        grokKey = prefs.getString("grok", null) ?: BuildConfig.GROK_API_KEY,
        lang = runCatching { Lang.valueOf(prefs.getString("lang", "BN")!!) }.getOrDefault(Lang.BN),
        mode = runCatching { Mode.valueOf(prefs.getString("mode", "FRIEND")!!) }.getOrDefault(Mode.FRIEND),
        voice = runCatching { VoiceGender.valueOf(prefs.getString("voice", "FEMALE")!!) }.getOrDefault(VoiceGender.FEMALE),
    )

    fun save(s: Settings) {
        prefs.edit()
            .putString("gemini", s.geminiKey)
            .putString("grok", s.grokKey)
            .putString("lang", s.lang.name)
            .putString("mode", s.mode.name)
            .putString("voice", s.voice.name)
            .apply()
    }
}
