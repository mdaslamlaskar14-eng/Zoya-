# Zoya — Android voice assistant (Kotlin + Jetpack Compose)

Real-time voice-to-voice assistant using the Gemini Live API (audio in, audio out) over a raw WebSocket,
with 8 phone-control tools (one of them asks Grok), a pseudo-3D Compose Canvas orb, Hindi / Bangla / English,
male or female voice, Friend or Assistant personality, a Quick Settings tile and a foreground mic service.

## Run it

1. Install Android Studio, then File > Open and choose this folder. Wait for Gradle sync.
   (If Studio asks about the Gradle wrapper, accept. It downloads Gradle 8.9 itself.)
2. Plug in your phone with USB debugging on, press Run.
3. In the app tap the Settings icon and paste your Gemini API key (and Grok key if you have one).
   Or copy `local.properties.example` to `local.properties` and fill the keys before building.
4. Allow microphone (and notifications on Android 13+). Tap the mic and talk.

## Code map

- `live/GeminiLiveClient.kt`   WebSocket session: setup, audio in/out, interruption, tool calls
- `audio/AudioEngine.kt`       16 kHz mic capture (echo cancel) + 24 kHz gapless playback + instant barge-in
- `ZoyaEngine.kt`              ties mic, session, tools and UI state together
- `tools/ToolRegistry.kt`      open_app, open_website, search_web, make_call, send_sms, set_alarm, toggle_flashlight, ask_grok
- `tools/GrokClient.kt`        xAI chat completions call
- `Persona.kt`                 system prompt: language, gender, Friend / Assistant mode, boundaries
- `service/ZoyaService.kt`     foreground microphone service (keeps the chat alive in background)
- `service/ZoyaTileService.kt` Quick Settings tile
- `ui/`                        theme, orb, main screen, guide sheet, settings dialog

## Good to know

- Opening other apps while Zoya is in the background needs "Display over other apps".
  The Guide sheet has a button that opens that setting.
- Calls and SMS only open the dialer / message screen. The user presses the final button.
- Model ids and voices change. `MODEL` in `ZoyaEngine.kt`, `MODEL` in `GrokClient.kt` and the voice
  names in `Settings.kt` are the three places to edit if Google or xAI rename something.
- API keys live in the app (SharedPreferences / BuildConfig). Fine for personal use. For a public release,
  put a small backend in front of Gemini and hand the app short-lived tokens instead.
- This does not replace Google Assistant as the phone's default assistant. That needs a native
  VoiceInteractionService, which is a separate piece of work.
